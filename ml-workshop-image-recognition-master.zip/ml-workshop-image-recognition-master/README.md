# Image recognition applied to Machine Learning
(A RMOTR workshop)

Here are the resources used for our workshop about Image Recognition and Machine learning. This is part of our 4-month [Python Data Science Bootcamp](https://rmotr.com/data-science-python-course?utm_campaign=workshops&source=github&medium=IP1).

---

<p align="center">
  <a href="https://rmotr.com" target="_blank"><img src="https://camo.githubusercontent.com/cc5541fa8bc6f822cb8d5b4261a23f20ec8321f4/68747470733a2f2f757365722d696d616765732e67697468756275736572636f6e74656e742e636f6d2f373036353430312f33393131393438362d34373138653338362d343665632d313165382d396663332d3532353061343965663537302e706e67"></a>
</p>
